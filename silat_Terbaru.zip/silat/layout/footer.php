    <!-- jQuery -->
    <script src="assets/plugin/js/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="assets/plugin/js/bootstrap.bundle.min.js"></script>
    <!-- Select2 Bootstrap 4 -->
    <script src="assets/plugin/js/select2.full.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="assets/plugin/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="assets/plugin/js/adminlte.min.js"></script>
    <!-- Sweet Alrert CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
$(function() {
    //Initialize Select2 Elements
    $('.select2bs4').select2({
        theme: 'bootstrap4',
    });
});
    </script>